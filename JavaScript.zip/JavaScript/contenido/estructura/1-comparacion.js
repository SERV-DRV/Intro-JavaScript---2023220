const a = 10;
const b = 20;
const c = "10"

console.log(a == b)//false
console.log(a === c)//false
console.log(a == c)//true
console.log(a != c)//false -> si se interpretan como iguales
console.log(a !== c)//true -> no se interpreta como iguales