//Tipos de datos string

let string1 = "Hola, mundo"
let string2 = "JvaScript es facilito!"
let string3 = '${string1} contento!}'
let string4 = string1 + " " + string2

console.log(string1)
console.log(string2)
console.log(string3)
console.log(string4)

let frase = "M37: Aprendo a Rezar el Rosario"
console.log(frase.length)
console.log(frase.toLocaleLowerCase())
console.log(frase.toUpperCase())
console.log