//Buenas Practicas
let cajaAudifonos = "derecho"
let urlDeUsuario = "https://www.google.com"
let carnetAlumno = "2023220"

//Malas Practicas
let c = "derecho"
let cd = "derecho"
let caUsuario = "derecho"

console.log(cajaAudifonos);

//Otras Formas
var nombre = "Alvaro"
nombre = "Carlos"
var edad;

const PI = 3.14159