/**
 * TIPOS DE DATOS: (1)PRIMITIVOS Y (2)COMPLEJOS [10 tipos]
 */
// (1) PRIMITIVOS
//String
let nombre = "Charly"

//Number
let edad = 31

//Boolean
let esMayorDeEdad = true

//Null
let noHayValor = null

//Undefied
let noDefinifo = undefined

//Symbol
let simboloUnico = Symbol("unico")

//BigInt
let numeroGrande = 2n

//console.log(numeroGrande);


//COMPLEJOS

//Object
let carro = {
    marca: "fiesta",
    color: "blanco",
    dueño: "mamon"
}

console.log(carro)

//Array
let frutas = ["manzana","banano","uvas"]

//Function
function name(params){
    //codigo
}
console.log(frutas)