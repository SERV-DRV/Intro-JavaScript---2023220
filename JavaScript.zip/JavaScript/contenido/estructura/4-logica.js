/**
* OPERADORES LOGICOS
*/
 
//AND, OR Y NOT - Y, O , NEGACION (NO)
 
// && : OPERADOR Y
// ||: OPERADOR 0
// !: OPERADOR DE NEGACIÓN
 
const a = 10;
const b = 20;
const c = "10";
 
(a == b && a === c) // false
(a != b || a === c) // true
!(a === c)