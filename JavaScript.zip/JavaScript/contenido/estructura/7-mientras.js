/**
 * 
 * 
 *              ESTRUCTURA DE WHILE
 * 
 * 
 */

let contador = 1;

while (contador<=10) {
    console.log(contador)
    contador++;
}
console.log("-----------------------------------")

//DO WHILE
contador = 1;
do{
    console.log(contador)
    contador++
}while(condition <=10);