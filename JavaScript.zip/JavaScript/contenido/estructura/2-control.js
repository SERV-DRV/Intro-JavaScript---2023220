/**
 * 
 * 
 * ESTRUCTURA DE CONTROL
 * 
 *  IF - ELSE IF - ELSE
 * 
 */

let nombre = "Kenneth";

if(nombre = "Kenneth"){
    console.log("Hola Kenneth")
} else if (nombre = "Carlos"){
    console.log("Hola Carlos")
}else {
    console.log("Error desconocido")
}